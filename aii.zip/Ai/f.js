const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const natural = require('natural');
const compromise = require('compromise');
const crypto = require('crypto');

// Database setup
const db = new sqlite3.Database('./brain.db');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        context TEXT,
        keywords TEXT,
        entities TEXT,
        confidence REAL DEFAULT 0.8,
        usage_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run(`CREATE TABLE IF NOT EXISTS group_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        message_id INTEGER,
        message_text TEXT NOT NULL,
        processed BOOLEAN DEFAULT 0,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run(`CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        is_admin BOOLEAN DEFAULT 0,
        auth_token TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
});

// NLP setup
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;
const analyzer = new natural.SentimentAnalyzer('English', stemmer, 'afinn');

const token = '7770178544:AAHQ-z5DqXNo6ymbq68-W7_aPXE1dhXLu94'; // Replace with your token
const bot = new TelegramBot(token, { polling: true });
const ADMIN_IDS = [7517568016];
const SECRET_PREFIX = '!';

// Detect English
function isEnglish(text) {
    return /^[\x00-\x7F\s.,?!'"(){}<>:;@#$%^&*\-+=_/\\|`~]+$/.test(text);
}

// Generate auth tokens
function generateToken() {
    return crypto.randomBytes(16).toString('hex');
}

class AIProcessor {
    static process(text) {
        const doc = compromise(text.toLowerCase());
        return {
            tokens: tokenizer.tokenize(text),
            nouns: doc.nouns().out('array'),
            verbs: doc.verbs().out('array'),
            sentiment: analyzer.getSentiment(text),
            isQuestion: /\?|what|how|why|when|who|where/i.test(text)
        };
    }

    static findMatch(input, knowledge) {
        const lower = input.toLowerCase();
        return knowledge.find(item =>
            item.question.toLowerCase().includes(lower) ||
            lower.includes(item.question.toLowerCase())
        );
    }
}

class KnowledgeSystem {
    static async learn(question, answer, userId = 0) {
        return new Promise((resolve, reject) => {
            const analysis = AIProcessor.process(question);
            db.run(`INSERT INTO knowledge (question, answer, keywords, entities) VALUES (?, ?, ?, ?)`,
                [question, answer, analysis.nouns.join(','), JSON.stringify(analysis)],
                function (err) {
                    if (err) return reject(err);
                    resolve(this.lastID);
                });
        });
    }

    static async recall(input) {
        return new Promise((resolve, reject) => {
            db.all(`SELECT * FROM knowledge`, [], (err, rows) => {
                if (err) return reject(err);
                const match = AIProcessor.findMatch(input, rows);
                if (match) {
                    db.run(`UPDATE knowledge SET usage_count = usage_count + 1 WHERE id = ?`, [match.id]);
                }
                resolve(match?.answer);
            });
        });
    }

    static async logGroupMessage(msg) {
        if (!msg.text || msg.text.startsWith('/') || !isEnglish(msg.text)) return;
        db.run(`INSERT INTO group_messages (group_id, user_id, message_id, message_text) 
                VALUES (?, ?, ?, ?)`,
            [msg.chat.id, msg.from.id, msg.message_id, msg.text]);
    }

    static async processGroupMessages() {
        return new Promise((resolve, reject) => {
            db.all(`SELECT * FROM group_messages WHERE processed = 0 LIMIT 50`, [], (err, messages) => {
                if (err) return reject(err);
                resolve(messages);
            });
        });
    }
}

class CommandSystem {
    static isAdmin(userId) {
        return ADMIN_IDS.includes(userId);
    }

    static async handleSecretCommand(msg) {
        if (!msg.text?.startsWith(SECRET_PREFIX)) return false;
        const userId = msg.from.id;
        if (!this.isAdmin(userId)) return true;

        const [cmd, ...args] = msg.text.slice(1).split(' ');
        switch (cmd.toLowerCase()) {
            case 'teach': {
                const [q, a] = args.join(' ').split('|').map(t => t.trim());
                if (!q || !a) {
                    bot.sendMessage(msg.chat.id, 'Usage: !teach <question> | <answer>');
                    return true;
                }
                if (!isEnglish(q) || !isEnglish(a)) {
                    bot.sendMessage(msg.chat.id, 'Only English input is accepted.');
                    return true;
                }
                await KnowledgeSystem.learn(q, a, userId);
                bot.sendMessage(msg.chat.id, '✅ Learned successfully!');
                return true;
            }
            case 'auth': {
                const token = generateToken();
                db.run(`INSERT OR REPLACE INTO users (user_id, auth_token) VALUES (?, ?)`, [userId, token]);
                bot.sendMessage(msg.chat.id, `🔐 Your auth token: ${token}`);
                return true;
            }
            default:
                bot.sendMessage(msg.chat.id, 'Unknown command.');
                return true;
        }
    }
}

// Message listener
bot.on('message', async (msg) => {
    try {
        if (await CommandSystem.handleSecretCommand(msg)) return;

        if (!msg.text || !isEnglish(msg.text)) return;

        if (msg.chat.type !== 'private') {
            await KnowledgeSystem.logGroupMessage(msg);
            return;
        }

        const response = await KnowledgeSystem.recall(msg.text) ||
            "🤖 I don't know this yet. Admins can teach me using `!teach`.";
        bot.sendMessage(msg.chat.id, response);
    } catch (err) {
        console.error("Error handling message:", err);
    }
});

// Auto-process group messages
setInterval(async () => {
    try {
        const messages = await KnowledgeSystem.processGroupMessages();
        for (const msg of messages) {
            const text = msg.message_text;
            if (isEnglish(text) && AIProcessor.process(text).isQuestion === true) {
                await KnowledgeSystem.learn(text, "🤖 I'm still learning. Ask again later.", msg.user_id);
            }
            db.run(`UPDATE group_messages SET processed = 1 WHERE id = ?`, [msg.id]);
        }
    } catch (err) {
        console.error("Background processing error:", err);
    }
}, 60000);

console.log("🤖 English AI Assistant is now running in Termux...");