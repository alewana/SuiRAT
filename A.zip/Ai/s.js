const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const natural = require('natural');
const compromise = require('compromise');
const crypto = require('crypto');

// Initialize database
const db = new sqlite3.Database('./brain.db');

// Enhanced database schema
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        context TEXT,
        keywords TEXT,
        entities TEXT,
        confidence REAL DEFAULT 0.8,
        usage_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS group_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        message_id INTEGER,
        message_text TEXT NOT NULL,
        processed BOOLEAN DEFAULT 0,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        is_admin BOOLEAN DEFAULT 0,
        auth_token TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
});

// NLP setup
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;
const analyzer = new natural.SentimentAnalyzer('English', stemmer, 'afinn');

// Bot setup
const token = '7770178544:AAHQ-z5DqXNo6ymbq68-W7_aPXE1dhXLu94';
const bot = new TelegramBot(token, { polling: true });
const ADMIN_IDS = [7517568016]; // Replace with your Telegram ID
const SECRET_PREFIX = '!'; // Hidden command prefix

// Generate auth tokens
function generateToken() {
    return crypto.randomBytes(16).toString('hex');
}

// Text processing
class AIProcessor {
    static process(text) {
        const doc = compromise(text.toLowerCase());
        return {
            tokens: tokenizer.tokenize(text),
            nouns: doc.nouns().out('array'),
            verbs: doc.verbs().out('array'),
            sentiment: analyzer.getSentiment(text),
            isQuestion: text.includes('?') || 
                       text.toLowerCase().startsWith('what') || 
                       text.toLowerCase().startsWith('how') ||
                       text.toLowerCase().startsWith('why')
        };
    }

    static findMatch(input, knowledge) {
        // Simple matching - expand with better NLP in production
        const processed = this.process(input);
        return knowledge.find(item => 
            item.question.toLowerCase().includes(input.toLowerCase()) || 
            input.toLowerCase().includes(item.question.toLowerCase())
        );
    }
}

// Knowledge Manager
class KnowledgeSystem {
    static async learn(question, answer, userId) {
        return new Promise((resolve, reject) => {
            const analysis = AIProcessor.process(question);
            db.run(
                `INSERT INTO knowledge (question, answer, keywords, entities) VALUES (?, ?, ?, ?)`,
                [question, answer, analysis.nouns.join(','), JSON.stringify(analysis)],
                function(err) {
                    if (err) return reject(err);
                    resolve(this.lastID);
                }
            );
        });
    }

    static async recall(input) {
        return new Promise((resolve, reject) => {
            db.all(`SELECT * FROM knowledge`, [], (err, rows) => {
                if (err) return reject(err);
                const match = AIProcessor.findMatch(input, rows);
                if (match) {
                    db.run(`UPDATE knowledge SET usage_count = usage_count + 1 WHERE id = ?`, [match.id]);
                }
                resolve(match?.answer);
            });
        });
    }

    static async logGroupMessage(msg) {
        if (!msg.text || msg.text.startsWith('/')) return;
        
        db.run(
            `INSERT INTO group_messages (group_id, user_id, message_id, message_text) 
             VALUES (?, ?, ?, ?)`,
            [msg.chat.id, msg.from.id, msg.message_id, msg.text]
        );
    }

    static async processGroupMessages() {
        return new Promise((resolve, reject) => {
            db.all(
                `SELECT * FROM group_messages WHERE processed = 0 LIMIT 50`,
                [],
                (err, messages) => {
                    if (err) return reject(err);
                    resolve(messages);
                }
            );
        });
    }
}

// Hidden command processor
class CommandSystem {
    static isAdmin(userId) {
        return ADMIN_IDS.includes(userId);
    }

    static async handleSecretCommand(msg) {
        if (!msg.text?.startsWith(SECRET_PREFIX)) return false;
        
        const userId = msg.from.id;
        if (!this.isAdmin(userId)) return true; // Silent ignore
        
        const [cmd, ...args] = msg.text.slice(1).split(' ');
        
        switch(cmd.toLowerCase()) {
            case 'teach':
                if (args.length < 2) {
                    bot.sendMessage(msg.chat.id, "Usage: !teach <question> | <answer>");
                    return true;
                }
                const [question, answer] = args.join(' ').split('|').map(s => s.trim());
                await KnowledgeSystem.learn(question, answer, userId);
                bot.sendMessage(msg.chat.id, "✅ Learned successfully!", { reply_to_message_id: msg.message_id });
                return true;
                
            case 'auth':
                const token = generateToken();
                db.run(
                    `INSERT OR REPLACE INTO users (user_id, auth_token) VALUES (?, ?)`,
                    [userId, token]
                );
                bot.sendMessage(msg.chat.id, `Your auth token: ${token}`, { reply_to_message_id: msg.message_id });
                return true;
                
            default:
                return true;
        }
    }
}

// Main bot handlers
bot.on('message', async (msg) => {
    try {
        // Process hidden commands first
        if (await CommandSystem.handleSecretCommand(msg)) return;
        
        // Log all group messages
        if (msg.chat.type !== 'private') {
            await KnowledgeSystem.logGroupMessage(msg);
            return;
        }
        
        // Handle direct messages
        const response = await KnowledgeSystem.recall(msg.text) || 
            "I'm not sure how to respond to that. My admins can teach me using hidden commands.";
        
        bot.sendMessage(msg.chat.id, response);
        
    } catch (err) {
        console.error('Message handling error:', err);
    }
});

// Background processing
setInterval(async () => {
    try {
        const messages = await KnowledgeSystem.processGroupMessages();
        for (const msg of messages) {
            // Analyze and learn from group messages
            db.run(
                `UPDATE group_messages SET processed = 1 WHERE id = ?`,
                [msg.id]
            );
        }
    } catch (err) {
        console.error('Background processing error:', err);
    }
}, 60000); // Process every minute

console.log('AI Assistant is running...');