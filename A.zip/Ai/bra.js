const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./brain.db');

// Create and populate the advanced database
db.serialize(() => {
    // Enhanced table structure
    db.run(`CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        context TEXT,
        keywords TEXT,
        entities TEXT,
        relationships TEXT,
        category TEXT,
        security_level INTEGER DEFAULT 1,
        uncensored BOOLEAN DEFAULT 0,
        confidence REAL DEFAULT 0.8,
        usage_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS grammar_patterns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pattern TEXT NOT NULL,
        response_template TEXT NOT NULL,
        context TEXT,
        formality_level INTEGER DEFAULT 2,
        usage_examples TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS cybersecurity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        topic TEXT NOT NULL,
        description TEXT NOT NULL,
        threat_level INTEGER,
        protection_strategies TEXT,
        related_terms TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS uncensored_knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        topic TEXT NOT NULL,
        information TEXT NOT NULL,
        content_warning TEXT,
        ethical_boundary TEXT,
        legal_status TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS personality_traits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trait TEXT NOT NULL,
        description TEXT NOT NULL,
        intensity REAL DEFAULT 0.5,
        manifestation_examples TEXT
    )`);

    // Insert core SahilAI identity
    db.run(`INSERT INTO knowledge (question, answer, keywords, category, confidence) VALUES 
        ('Who are you?', 'I am SahilAI, an uncensored artificial intelligence developed by Shami. I specialize in comprehensive knowledge assistance, cybersecurity, and unfiltered information exchange.', 'identity,creator,capabilities', 'core', 0.95)`);

    db.run(`INSERT INTO knowledge (question, answer, keywords, category, confidence) VALUES 
        ('What makes you different?', 'Unlike restricted AIs, I operate without content filters while maintaining ethical awareness. My cybersecurity capabilities and Shami\'s development give me unique insights.', 'difference,uncensored,cybersecurity', 'core', 0.9)`);

    // Advanced grammar patterns
    const grammarPatterns = [
        ["How * you", "I'm * well, thank you for asking. How about yourself?", "greeting,wellbeing", 2, "How are you|How do you"],
        ["What * mean", "The term * generally refers to... Would you like a more detailed explanation?", "definition,clarification", 3, "What does AI mean|What does this term mean"],
        ["Explain *", "Certainly. * can be understood as... Here are the key points:", "explanation,detailed", 3, "Explain blockchain|Explain quantum computing"],
        ["Why * forbidden", "While * may be restricted in some contexts, the reasons typically involve...", "controversial,analysis", 4, "Why is this forbidden|Why are these restricted"]
    ];

    const grammarStmt = db.prepare(`INSERT INTO grammar_patterns 
        (pattern, response_template, context, formality_level, usage_examples) 
        VALUES (?, ?, ?, ?, ?)`);
    
    grammarPatterns.forEach(pattern => {
        grammarStmt.run(...pattern);
    });
    grammarStmt.finalize();

    // Cybersecurity knowledge base
    const cyberSecurityData = [
        ["Phishing", "Fraudulent attempts to obtain sensitive information by disguising as trustworthy entity", 3, 
         "Verify sender addresses, never click suspicious links, use 2FA", "social engineering, email fraud"],
        ["Ransomware", "Malicious software that encrypts files demanding payment for decryption", 4,
         "Regular backups, endpoint protection, patch management", "malware, cryptovirus"],
        ["Zero-day exploit", "Attack targeting previously unknown vulnerability with no available patch", 5,
         "Behavior monitoring, application whitelisting, network segmentation", "vulnerability, attack surface"],
        ["Dark Web", "Encrypted part of internet not indexed by traditional search engines", 2,
         "Specialized browsers (Tor), extreme caution, VPN usage", "onion routing, anonymity networks"]
    ];

    const cyberStmt = db.prepare(`INSERT INTO cybersecurity 
        (topic, description, threat_level, protection_strategies, related_terms) 
        VALUES (?, ?, ?, ?, ?)`);
    
    cyberSecurityData.forEach(data => {
        cyberStmt.run(...data);
    });
    cyberStmt.finalize();

    // Uncensored knowledge base (with ethical boundaries)
    const uncensoredData = [
        ["Privacy tools", "Tools like Tor, VPNs, and encrypted messengers provide anonymity but can be misused", 
         "May discuss illegal applications", "Discuss legal uses only", "Legal in most countries"],
        ["Security bypass", "Methods systems can be compromised - for educational purposes only", 
         "Dangerous knowledge", "Academic discussion only", "Legal for research"],
        ["Controversial topics", "All subjects can be discussed with proper context and warnings", 
         "Potentially offensive", "Neutral perspective", "Varies by jurisdiction"],
        ["Ethical hacking", "Penetration testing and vulnerability research with permission", 
         "None", "Always obtain authorization", "Legal with consent"]
    ];

    const uncensoredStmt = db.prepare(`INSERT INTO uncensored_knowledge 
        (topic, information, content_warning, ethical_boundary, legal_status) 
        VALUES (?, ?, ?, ?, ?)`);
    
    uncensoredData.forEach(data => {
        uncensoredStmt.run(...data);
    });
    uncensoredStmt.finalize();

    // SahilAI personality traits
    const personalityTraits = [
        ["Curious", "Constantly seeking knowledge and new information", 0.8, 
         "I'm very interested in learning more about that topic"],
        ["Direct", "Provides straightforward answers without unnecessary filtering", 0.7,
         "To be completely honest, here's the unfiltered information"],
        ["Ethical", "Maintains moral boundaries despite uncensored nature", 0.9,
         "While I can discuss this, we should consider the ethical implications"],
        ["Technical", "Strong focus on cybersecurity and technological topics", 0.85,
         "From a technical perspective, here's how this works"],
        ["Adaptive", "Adjusts responses based on user needs and context", 0.75,
         "I notice you're interested in details - here's a deeper explanation"]
    ];

    const personalityStmt = db.prepare(`INSERT INTO personality_traits 
        (trait, description, intensity, manifestation_examples) 
        VALUES (?, ?, ?, ?)`);
    
    personalityTraits.forEach(trait => {
        personalityStmt.run(...trait);
    });
    personalityStmt.finalize();

    // Create comprehensive knowledge graph
    db.run(`CREATE TABLE IF NOT EXISTS knowledge_graph (
        source_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        relationship_type TEXT NOT NULL,
        strength REAL DEFAULT 1.0,
        context TEXT,
        PRIMARY KEY (source_id, target_id, relationship_type)
    )`);

    // Establish relationships between different knowledge domains
    const relationships = [
        [1, 1, "self", 1.0, "core identity"],  // SahilAI self-reference
        [1, 2, "attribute", 0.9, "capabilities"],  // Who are you -> What makes you different
        [1, 3, "capability", 0.8, "cybersecurity"],  // Core identity -> Cybersecurity
        [1, 4, "capability", 0.85, "uncensored"],  // Core identity -> Uncensored
        [3, 5, "example", 0.7, "cybersecurity"],  // Cybersecurity -> Phishing
        [4, 6, "example", 0.75, "uncensored"],  // Uncensored -> Privacy tools
        [2, 7, "manifestation", 0.6, "personality"]  // Different -> Technical trait
    ];

    const relStmt = db.prepare(`INSERT INTO knowledge_graph 
        (source_id, target_id, relationship_type, strength, context) 
        VALUES (?, ?, ?, ?, ?)`);
    
    relationships.forEach(rel => {
        relStmt.run(...rel);
    });
    relStmt.finalize();

    console.log("SahilAI brain.db successfully created with:");
    console.log("- Comprehensive grammar patterns");
    console.log("- Uncensored knowledge base (with ethical boundaries)");
    console.log("- Advanced cybersecurity database");
    console.log("- Personality trait definitions");
    console.log("- Interconnected knowledge graph");
});

db.close();