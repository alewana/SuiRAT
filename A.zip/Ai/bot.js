const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const stringSimilarity = require('string-similarity');
const natural = require('natural');
const compromise = require('compromise');
const word2vec = require('node-word2vec');
const fs = require('fs');
const path = require('path');

// Initialize enhanced database
const db = new sqlite3.Database('./brain.db');

// Create advanced database schema
db.serialize(() => {
    // Knowledge base with relationships
    db.run(`CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        context TEXT,
        keywords TEXT,
        entities TEXT,
        relationships TEXT,
        confidence REAL DEFAULT 0.7,
        usage_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    // Conversation history with context tracking
    db.run(`CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        chat_id INTEGER NOT NULL,
        message_id INTEGER NOT NULL,
        user_input TEXT NOT NULL,
        bot_response TEXT,
        context_chain TEXT,
        intent TEXT,
        sentiment REAL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    // User profiles for personalized learning
    db.run(`CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        learning_style TEXT DEFAULT 'balanced',
        knowledge_level INTEGER DEFAULT 1,
        preferred_topics TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    // Feedback system for continuous improvement
    db.run(`CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        knowledge_id INTEGER,
        conversation_id INTEGER,
        is_correct BOOLEAN,
        correction TEXT,
        user_id INTEGER,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(knowledge_id) REFERENCES knowledge(id),
        FOREIGN KEY(conversation_id) REFERENCES conversations(id)
    )`);

    // Knowledge relationships graph
    db.run(`CREATE TABLE IF NOT EXISTS knowledge_graph (
        source_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        relationship_type TEXT NOT NULL,
        strength REAL DEFAULT 1.0,
        PRIMARY KEY (source_id, target_id, relationship_type),
        FOREIGN KEY(source_id) REFERENCES knowledge(id),
        FOREIGN KEY(target_id) REFERENCES knowledge(id)
    )`);
});

// Initialize NLP tools
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;
const tfidf = new natural.TfIdf();
const classifier = new natural.BayesClassifier();
const sentimentAnalyzer = new natural.SentimentAnalyzer('English', stemmer, 'afinn');

// Initialize Word2Vec model (train or load pre-trained)
const word2vec = new Word2Vec();
const w2vModelPath = path.join(__dirname, 'word2vec.model');
if (fs.existsSync(w2vModelPath)) {
    word2vec.loadModel(w2vModelPath);
} else {
    // Train with initial corpus
    const sentences = [
        ['hello', 'hi', 'greeting'],
        ['goodbye', 'bye', 'farewell'],
        ['how', 'are', 'you'],
        ['what', 'is', 'your', 'name'],
        ['thank', 'you', 'thanks']
    ];
    word2vec.train(sentences);
    word2vec.saveModel(w2vModelPath);
}

// Telegram bot setup
const token = '7770178544:AAHQ-z5DqXNo6ymbq68-W7_aPXE1dhXLu94';
const bot = new TelegramBot(token, { polling: true });

// Enhanced text processing pipeline
class TextProcessor {
    static preprocess(text) {
        if (!text) return '';
        return text.toLowerCase()
            .replace(/[^\w\s]/gi, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    static tokenize(text) {
        return tokenizer.tokenize(this.preprocess(text));
    }

    static stem(text) {
        return this.tokenize(text).map(token => stemmer.stem(token)).join(' ');
    }

    static extractEntities(text) {
        const doc = compromise(text);
        return {
            nouns: doc.nouns().out('array'),
            verbs: doc.verbs().out('array'),
            adjectives: doc.adjectives().out('array'),
            organizations: doc.organizations().out('array'),
            people: doc.people().out('array'),
            places: doc.places().out('array')
        };
    }

    static extractKeywords(text) {
        const entities = this.extractEntities(text);
        return [...new Set([
            ...entities.nouns,
            ...entities.verbs,
            ...entities.adjectives
        ])].filter(k => k.length > 2).join(',');
    }

    static analyzeSentiment(text) {
        return sentimentAnalyzer.getSentiment(this.tokenize(text));
    }

    static detectIntent(text) {
        // This would be enhanced with real ML in production
        const lcText = text.toLowerCase();
        if (lcText.includes('?')) return 'question';
        if (lcText.startsWith('how') || lcText.startsWith('what') || lcText.startsWith('why')) return 'question';
        if (lcText.includes('thank')) return 'gratitude';
        if (lcText.includes('hi') || lcText.includes('hello')) return 'greeting';
        return 'statement';
    }

    static getWordEmbedding(word) {
        return word2vec.getVector(word) || Array(100).fill(0); // Default 100-dim zero vector
    }

    static textSimilarity(text1, text2) {
        // Combine string similarity with semantic similarity
        const stringSim = stringSimilarity.compareTwoStrings(text1, text2);
        const tokens1 = this.tokenize(text1);
        const tokens2 = this.tokenize(text2);
        
        if (tokens1.length === 0 || tokens2.length === 0) return stringSim;
        
        // Simple semantic similarity (would be enhanced in production)
        const vec1 = tokens1.map(w => this.getWordEmbedding(w)).reduce((a, b) => a.map((v, i) => v + b[i]), Array(100).fill(0));
        const vec2 = tokens2.map(w => this.getWordEmbedding(w)).reduce((a, b) => a.map((v, i) => v + b[i]), Array(100).fill(0));
        
        const dotProduct = vec1.map((v, i) => v * vec2[i]).reduce((a, b) => a + b, 0);
        const magnitude1 = Math.sqrt(vec1.reduce((a, b) => a + b * b, 0));
        const magnitude2 = Math.sqrt(vec2.reduce((a, b) => a + b * b, 0));
        
        const semanticSim = magnitude1 && magnitude2 ? dotProduct / (magnitude1 * magnitude2) : 0;
        
        return (stringSim * 0.6) + (semanticSim * 0.4);
    }
}

// Knowledge Manager handles memory and learning
class KnowledgeManager {
    static async findBestResponse(userInput, userId, chatId) {
        return new Promise((resolve, reject) => {
            const processedInput = TextProcessor.preprocess(userInput);
            const keywords = TextProcessor.extractKeywords(userInput);
            const intent = TextProcessor.detectIntent(userInput);
            const sentiment = TextProcessor.analyzeSentiment(userInput);
            
            // Get conversation context
            this.getConversationContext(userId, chatId).then(context => {
                db.all(`SELECT id, question, answer, confidence FROM knowledge`, [], async (err, rows) => {
                    if (err) return reject(err);
                    
                    if (rows.length === 0) return resolve(null);
                    
                    // Find matches considering context
                    const matches = await this.findMatches(rows, userInput, context);
                    
                    if (matches.length > 0) {
                        const bestMatch = matches[0];
                        
                        // Update usage and learn from this interaction
                        this.recordInteraction({
                            userId,
                            chatId,
                            userInput,
                            botResponse: bestMatch.answer,
                            knowledgeId: bestMatch.id,
                            context,
                            intent,
                            sentiment
                        });
                        
                        // Improve this knowledge over time
                        if (bestMatch.confidence < 0.85 || bestMatch.usage_count % 5 === 0) {
                            this.improveKnowledge(bestMatch.id, chatId);
                        }
                        
                        return resolve({
                            response: bestMatch.answer,
                            id: bestMatch.id,
                            confidence: bestMatch.confidence,
                            context
                        });
                    }
                    
                    resolve(null);
                });
            });
        });
    }

    static async findMatches(knowledgeItems, userInput, context) {
        const matches = [];
        
        for (const item of knowledgeItems) {
            // Basic string similarity
            const similarity = TextProcessor.textSimilarity(userInput, item.question);
            
            // Context matching
            let contextMatch = 0;
            if (context && context.lastTopics) {
                const itemContext = JSON.parse(item.context || '{}');
                const itemTopics = itemContext.topics || [];
                contextMatch = itemTopics.some(topic => context.lastTopics.includes(topic)) ? 0.2 : 0;
            }
            
            // Combined score
            const score = similarity + contextMatch;
            
            if (score > 0.65) {
                matches.push({
                    ...item,
                    matchScore: score
                });
            }
        }
        
        // Sort by best match
        return matches.sort((a, b) => b.matchScore - a.matchScore);
    }

    static async getConversationContext(userId, chatId, depth = 3) {
        return new Promise((resolve) => {
            db.all(`SELECT user_input, bot_response FROM conversations 
                   WHERE user_id = ? AND chat_id = ? 
                   ORDER BY timestamp DESC LIMIT ?`, 
                  [userId, chatId, depth], (err, rows) => {
                if (err || rows.length === 0) return resolve(null);
                
                const lastTopics = [];
                const lastIntents = [];
                
                rows.forEach(row => {
                    const inputEntities = TextProcessor.extractEntities(row.user_input);
                    lastTopics.push(...inputEntities.nouns);
                    
                    if (row.bot_response) {
                        const responseEntities = TextProcessor.extractEntities(row.bot_response);
                        lastTopics.push(...responseEntities.nouns);
                    }
                });
                
                resolve({
                    lastTopics: [...new Set(lastTopics)].slice(0, 5),
                    lastMessages: rows.map(r => r.user_input).slice(0, 3),
                    lastIntents: [...new Set(lastIntents)]
                });
            });
        });
    }

    static recordInteraction(data) {
        const { userId, chatId, userInput, botResponse, knowledgeId, context, intent, sentiment } = data;
        
        // Update knowledge usage
        db.run(`UPDATE knowledge SET usage_count = usage_count + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [knowledgeId]);
        
        // Save conversation
        db.run(`INSERT INTO conversations 
               (user_id, chat_id, user_input, bot_response, context_chain, intent, sentiment)
               VALUES (?, ?, ?, ?, ?, ?, ?)`,
              [userId, chatId, userInput, botResponse, JSON.stringify(context), intent, sentiment]);
        
        // Update user profile
        db.run(`INSERT OR IGNORE INTO users (user_id) VALUES (?)`, [userId]);
        db.run(`UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE user_id = ?`, [userId]);
    }

    static improveKnowledge(knowledgeId, chatId) {
        db.get(`SELECT question, answer, confidence FROM knowledge WHERE id = ?`, [knowledgeId], (err, row) => {
            if (!row) return;
            
            const improvedAnswer = this.generateImprovedAnswer(row.question, row.answer);
            
            if (improvedAnswer !== row.answer) {
                db.run(`UPDATE knowledge SET answer = ?, confidence = ?, updated_at = CURRENT_TIMESTAMP 
                       WHERE id = ?`, [improvedAnswer, Math.min(1, row.confidence + 0.05), knowledgeId]);
                
                bot.sendMessage(chatId, `ℹ️ I've improved my understanding of "${row.question.substring(0, 50)}..."`);
            }
        });
    }

    static generateImprovedAnswer(question, currentAnswer) {
        // Analyze current answer
        const answerSentiment = TextProcessor.analyzeSentiment(currentAnswer);
        const answerLength = currentAnswer.split(' ').length;
        const isQuestion = TextProcessor.detectIntent(question) === 'question';
        
        // Generate improved version
        if (isQuestion && answerLength < 8) {
            const entities = TextProcessor.extractEntities(question);
            if (entities.nouns.length > 0) {
                return `Regarding ${entities.nouns[0]}, ${currentAnswer}. Would you like more details?`;
            }
            return `To answer your question, ${currentAnswer}. I can elaborate if needed.`;
        }
        
        if (answerSentiment < -0.3) {
            return currentAnswer.replace(/\b(no|don't|can't)\b/gi, match => 
                ['perhaps', 'maybe', 'possibly'][Math.floor(Math.random() * 3)]
            );
        }
        
        return currentAnswer;
    }

    static async learnFromConversation(conversationId) {
        // Analyze conversation patterns and update knowledge
        // This would be enhanced with proper ML in production
        db.get(`SELECT user_input, bot_response FROM conversations WHERE id = ?`, [conversationId], (err, row) => {
            if (!row) return;
            
            const inputEntities = TextProcessor.extractEntities(row.user_input);
            const responseEntities = TextProcessor.extractEntities(row.bot_response);
            
            // Create knowledge relationships
            if (inputEntities.nouns.length > 0 && responseEntities.nouns.length > 0) {
                inputEntities.nouns.forEach(noun => {
                    responseEntities.nouns.forEach(responseNoun => {
                        db.run(`INSERT OR IGNORE INTO knowledge_graph 
                              (source_id, target_id, relationship_type) 
                              VALUES (
                                  (SELECT id FROM knowledge WHERE question LIKE ? LIMIT 1),
                                  (SELECT id FROM knowledge WHERE answer LIKE ? LIMIT 1),
                                  'related'
                              )`, [`%${noun}%`, `%${responseNoun}%`]);
                    });
                });
            }
        });
    }

    static async analyzeKnowledgeGaps() {
        // Find unanswered questions or weak knowledge areas
        db.all(`SELECT user_input FROM conversations 
               WHERE bot_response IS NULL OR bot_response LIKE 'I don%' 
               GROUP BY user_input HAVING COUNT(*) > 1 LIMIT 5`, [], (err, rows) => {
            if (rows.length > 0) {
                rows.forEach(row => {
                    db.run(`INSERT OR IGNORE INTO knowledge (question, answer, confidence) 
                          VALUES (?, 'I don\'t know about this yet. Can you teach me?', 0.5)`, 
                          [row.user_input]);
                });
            }
        });
    }
}

// Command handlers
bot.onText(/\/start/, (msg) => {
    const welcomeMsg = `🧠 *Welcome to Advanced Memory Bot* 🧠

I'm an AI with advanced learning capabilities. Here's what I can do:

• Remember everything you teach me
• Learn from our conversations
• Improve my responses over time
• Understand context and relationships

Commands:
/teach - Teach me something new
/recall - Ask what I remember
/feedback - Help me improve
/stats - See my knowledge base`;

    bot.sendMessage(msg.chat.id, welcomeMsg, { parse_mode: 'Markdown' });
});

bot.onText(/\/teach/, (msg) => {
    bot.sendMessage(msg.chat.id, "📚 Teaching mode activated. Please send your knowledge in this format:\n\n*Question* | *Answer*\n\nExample:\nWhat is the capital of France? | The capital of France is Paris.", { parse_mode: 'Markdown' });
});

bot.onText(/\/recall/, (msg) => {
    bot.sendMessage(msg.chat.id, "🔍 What would you like me to recall? Ask me any question and I'll search my memory.");
});

bot.onText(/\/stats/, (msg) => {
    db.get(`SELECT COUNT(*) as knowledge_count FROM knowledge`, (err, row) => {
        db.get(`SELECT COUNT(*) as conversation_count FROM conversations WHERE user_id = ?`, [msg.from.id], (err, userRow) => {
            const statsMsg = `📊 *Knowledge Stats*:
- Total facts: ${row.knowledge_count}
- Conversations with you: ${userRow.conversation_count}
- Learning rate: ${Math.min(100, Math.floor(row.knowledge_count / 10))}%`;

            bot.sendMessage(msg.chat.id, statsMsg, { parse_mode: 'Markdown' });
        });
    });
});

// Main message handler
bot.on('message', async (msg) => {
    if (msg.text.startsWith('/')) return; // Skip commands
    
    const userMessage = msg.text;
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    try {
        // Check if in teaching mode
        if (msg.reply_to_message && msg.reply_to_message.text.includes("Teaching mode activated")) {
            const parts = userMessage.split('|').map(part => part.trim());
            if (parts.length === 2) {
                const question = parts[0];
                const answer = parts[1];
                const keywords = TextProcessor.extractKeywords(question);
                const entities = TextProcessor.extractEntities(question);
                const context = {
                    topics: entities.nouns,
                    isQuestion: TextProcessor.detectIntent(question) === 'question',
                    sentiment: TextProcessor.analyzeSentiment(question)
                };
                
                db.run(`INSERT INTO knowledge (question, answer, keywords, entities, context) 
                       VALUES (?, ?, ?, ?, ?)`,
                      [question, answer, keywords, JSON.stringify(entities), JSON.stringify(context)], (err) => {
                    if (err) {
                        bot.sendMessage(chatId, "❌ I couldn't save that. Please try a different format.");
                    } else {
                        bot.sendMessage(chatId, "✅ Thank you! I've added this to my knowledge base.");
                        // Train classifier with new example
                        classifier.addDocument(question, 'known_answer');
                        classifier.train();
                    }
                });
                return;
            }
        }
        
        // Find best response from knowledge base
        const response = await KnowledgeManager.findBestResponse(userMessage, userId, chatId);
        
        if (response) {
            bot.sendMessage(chatId, response.response);
            
            // Check if we should expand on this answer
            if (response.confidence > 0.8 && Math.random() < 0.3) {
                this.expandOnAnswer(response.id, chatId);
            }
        } else {
            // No good match found - engage in learning
            const defaultAnswer = "I'm not entirely sure about that. Could you teach me the appropriate response?";
            bot.sendMessage(chatId, defaultAnswer);
            
            // Save the interaction for later learning
            const keywords = TextProcessor.extractKeywords(userMessage);
            const entities = TextProcessor.extractEntities(userMessage);
            const context = {
                topics: entities.nouns,
                isQuestion: TextProcessor.detectIntent(userMessage) === 'question',
                sentiment: TextProcessor.analyzeSentiment(userMessage)
            };
            
            db.run(`INSERT INTO knowledge (question, answer, keywords, entities, context, confidence) 
                  VALUES (?, ?, ?, ?, ?, ?)`,
                  [userMessage, defaultAnswer, keywords, JSON.stringify(entities), JSON.stringify(context), 0.5]);
            
            // Record conversation
            KnowledgeManager.recordInteraction({
                userId,
                chatId,
                userInput: userMessage,
                botResponse: defaultAnswer,
                knowledgeId: null,
                context,
                intent: TextProcessor.detectIntent(userMessage),
                sentiment: TextProcessor.analyzeSentiment(userMessage)
            });
        }
    } catch (error) {
        console.error('Error processing message:', error);
        bot.sendMessage(chatId, "I encountered a problem processing your message. Please try again.");
    }
});

// Feedback handler
bot.on('message', (msg) => {
    if (msg.reply_to_message && msg.reply_to_message.from.username === bot.options.username) {
        const feedback = msg.text.toLowerCase();
        const isPositive = feedback.includes('correct') || feedback.includes('right') || feedback.includes('good');
        const isNegative = feedback.includes('wrong') || feedback.includes('incorrect') || feedback.includes('bad');
        
        if (isPositive || isNegative) {
            // Find the knowledge entry that matches the bot's response
            const botResponse = msg.reply_to_message.text;
            db.get(`SELECT id FROM knowledge WHERE answer = ? ORDER BY usage_count DESC LIMIT 1`, 
                  [botResponse], (err, row) => {
                if (row) {
                    db.run(`INSERT INTO feedback (knowledge_id, is_correct, user_id) VALUES (?, ?, ?)`,
                          [row.id, isPositive, msg.from.id]);
                    
                    // Adjust confidence based on feedback
                    const adjustment = isPositive ? 0.05 : -0.1;
                    db.run(`UPDATE knowledge SET confidence = confidence + ? WHERE id = ?`, 
                          [adjustment, row.id]);
                    
                    bot.sendMessage(msg.chat.id, "📝 Thanks for your feedback! I'll use this to improve.");
                    
                    // If negative feedback with correction, learn from it
                    if (isNegative && feedback.length > 10) {
                        db.run(`UPDATE knowledge SET answer = ? WHERE id = ?`, 
                              [feedback, row.id]);
                    }
                }
            });
        }
    }
});

// Expand on related knowledge
function expandOnAnswer(knowledgeId, chatId) {
    db.get(`SELECT question, answer FROM knowledge WHERE id = ?`, [knowledgeId], (err, row) => {
        if (!row) return;
        
        // Find related knowledge
        db.all(`SELECT k.question, k.answer FROM knowledge k
               JOIN knowledge_graph kg ON k.id = kg.target_id
               WHERE kg.source_id = ? AND kg.relationship_type = 'related'
               ORDER BY kg.strength DESC LIMIT 1`, [knowledgeId], (err, relatedRows) => {
            if (relatedRows.length > 0) {
                setTimeout(() => {
                    bot.sendMessage(chatId, `ℹ️ Related information: ${relatedRows[0].answer}`);
                }, 1500);
            }
        });
    });
}

// Periodic self-improvement tasks
setInterval(() => {
    // Improve weak knowledge
    db.all(`SELECT id FROM knowledge WHERE confidence < 0.7 ORDER BY RANDOM() LIMIT 3`, [], (err, rows) => {
        rows.forEach(row => KnowledgeManager.improveKnowledge(row.id, null));
    });
    
    // Analyze conversation patterns
    KnowledgeManager.analyzeKnowledgeGaps();
    
    // Train word2vec with new words from knowledge base
    db.all(`SELECT question FROM knowledge ORDER BY updated_at DESC LIMIT 100`, [], (err, rows) => {
        if (rows.length > 0) {
            const sentences = rows.map(row => 
                TextProcessor.tokenize(row.question).map(word => stemmer.stem(word))
            );
            word2vec.train(sentences);
            word2vec.saveModel(w2vModelPath);
        }
    });
}, 86400000); // Run daily

console.log('🤖 Advanced Memory Bot is running...');